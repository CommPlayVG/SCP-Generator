The contents of this text is comprised of the UNDERSTANDABLE VERSION OF THE LICENSE and
at the bottom is the INSTRUCTIONS on how to use the generator



The following is a human-readable summary of (and not a substitute for) the license found
in the same folder as this file. It is only a basic, comprehensible version of the license
needing no legal experience to understand. Everything below goes for anything from The SCP Generator
made by CommPlayVG and anything in this folder this text file is in

You are free to:
Share � meaining to copy and redistribute the material in any medium or format
Adapt � meaning to remix, transform, and build upon the material

The licensor (CommPlayVG) cannot revoke these freedoms as long as you follow the license 
terms.

Under the following terms:

Attribution � This means you must give appropriate credit, provide a 
link to the license, and indicate if changes were made. You 
may do so in any reasonable manner, but not in any way that 
suggests the licensor (CommPlayVG) endorses you or your use.

NonCommercial � This means you may not use the material for 
commercial (Moneymaking) purposes.

ShareAlike � Thsi means that if you remix, transform, or build upon 
the material, you must distribute your contributions under the 
same license as the original.

No additional restrictions � This means that you may not apply legal terms 
or technological measures that legally restrict others from 
doing anything the license permits.

Notices:
You do not have to comply with the license for elements of 
the material in the public domain or where your use is 
permitted by an applicable exception or limitation.

No warranties are given. The license may not give you all of 
the permissions necessary for your intended use. For 
example, other rights such as publicity, privacy, or moral 
rights may limit how you use the material.

Thank you, and have a great time!

TO OPEN:
Simply click the index or index.html file to open, and there will be two 
scroll bars, one to scroll through the wiki page, and another to scroll down to the bottom 
of the generator itself to find the buttons to start the random generation process.

