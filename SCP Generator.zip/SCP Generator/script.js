var num;
var scp;
var min;
var max;

function myFunction() {
    min = 2;
    max = 4999;
    num = Math.floor(Math.random() * (+max - +min)) + +min;
    if (num < 10) {
        scp = '00' + num;
    } else if (num > 9 && num < 100) {
        scp = '0' + num;
    } else {
        scp = num;
    }
    document.getElementById("scpwiki").data = 'http://www.scp-wiki.net/scp-' + scp;
    document.getElementById("text").innerHTML = 'SCP-' + scp + ' (' + min + ' to ' + max + ')';
}



function seriesone() {
    min = 2;
    max = 999;
    num = Math.floor(Math.random() * (+max - +min)) + +min;
    if (num < 10) {
        scp = '00' + num;
    } else if (num > 9 && num < 100) {
        scp = '0' + num;
    } else {
        scp = num;
    }
    document.getElementById("scpwiki").data = 'http://www.scp-wiki.net/scp-' + scp;

    document.getElementById("text").innerHTML = 'SCP-' + scp + ' (' + min + ' to ' + max + ')';
}

function seriestwo() {
    min = 1000;
    max = 1999;
    num = Math.floor(Math.random() * (+max - +min)) + +min;
    if (num < 10) {
        scp = '00' + num;
    } else if (num > 9 && num < 100) {
        scp = '0' + num;
    } else {
        scp = num;
    }
    document.getElementById("scpwiki").data = 'http://www.scp-wiki.net/scp-' + scp;

    document.getElementById("text").innerHTML = 'SCP-' + scp + ' (' + min + ' to ' + max + ')';
}

function seriesthree() {
    min = 2000;
    max = 2999;
    num = Math.floor(Math.random() * (+max - +min)) + +min;
    if (num < 10) {
        scp = '00' + num;
    } else if (num > 9 && num < 100) {
        scp = '0' + num;
    } else {
        scp = num;
    }
    document.getElementById("scpwiki").data = 'http://www.scp-wiki.net/scp-' + scp;

    document.getElementById("text").innerHTML = 'SCP-' + scp + ' (' + min + ' to ' + max + ')';
}

function seriesfour() {
    min = 3000;
    max = 3999;
    num = Math.floor(Math.random() * (+max - +min)) + +min;
    if (num < 10) {
        scp = '00' + num;
    } else if (num > 9 && num < 100) {
        scp = '0' + num;
    } else {
        scp = num;
    }
    document.getElementById("scpwiki").data = 'http://www.scp-wiki.net/scp-' + scp;

    document.getElementById("text").innerHTML = 'SCP-' + scp + ' (' + min + ' to ' + max + ')';
}

function seriesfive() {
    min = 4000;
    max = 4999;
    num = Math.floor(Math.random() * (+max - +min)) + +min;
    if (num < 10) {
        scp = '00' + num;
    } else if (num > 9 && num < 100) {
        scp = '0' + num;
    } else {
        scp = num;
    }
    document.getElementById("scpwiki").data = 'http://www.scp-wiki.net/scp-' + scp;

    document.getElementById("text").innerHTML = 'SCP-' + scp + ' (' + min + ' to ' + max + ')';
}
